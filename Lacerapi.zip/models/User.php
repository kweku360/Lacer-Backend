<?php
/**
 * Created by PhpStorm.
 * User: apple
 * Date: 8/20/15
 * Time: 4:31 AM
 */

class User extends  ActiveRecord\Model {

}