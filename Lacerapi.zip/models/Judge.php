<?php
/**
 * Created by Kweku kankam for AEON CONNECT.
 * LACER project
 * Date: 8/19/15
 * Time: 4:27 PM
 */

class Judge extends ActiveRecord\Model {


}