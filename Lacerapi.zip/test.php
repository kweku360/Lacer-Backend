<?php echo phpinfo() ?>
